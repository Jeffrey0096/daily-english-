# Daily English

A 120-day English course for your phone. Each day you get one grammar lesson from *Oxford Practice Grammar – Basic* and a set of words from *Oxford Word Skills – Intermediate*. Lessons include short explanations, examples you can listen to, and quick quizzes. A daily reminder helps you keep your streak.

## Install on Android

1. On your phone, open the **Releases** page of this repository and tap the newest release.
2. Download **DailyEnglish.apk** and open it.
3. If Android asks, allow installing apps from your browser or Files app, then tap **Install**.
4. Open Daily English and allow notifications so you get your daily reminder (7:00 PM by default — you can change the time in the app).

Direct link to the newest version: `https://github.com/<owner>/daily-english/releases/latest/download/DailyEnglish.apk`

To update, install the newest APK over the old one. Your progress stays on your phone.

## Use on iPhone

Open the web version (GitHub Pages) in **Safari**, tap **Share**, then **Add to Home Screen**. It works offline. iPhones can't install this app's reminders, so use a calendar reminder instead.

## How the app is built

- `www/` — the app itself (HTML, lesson data in `lessons.json`, fonts, icons).
- `resources/android/res/` — app icon, notification icon and splash screen for Android.
- `.github/workflows/android.yml` — every push to `main` builds a signed APK with [Capacitor](https://capacitorjs.com) and publishes it as a GitHub Release.
- `.github/workflows/pages.yml` — publishes `www/` to GitHub Pages (the web and iPhone version).

You can also start a build by hand: **Actions → Build Android app → Run workflow**.

### Signing key (do this once)

Android only installs an update over the old app if both are signed with the same key. Keep your key out of this repository and give it to GitHub as two **secrets**:

1. In this repository, go to **Settings → Secrets and variables → Actions → New repository secret**.
2. Add `ANDROID_KEYSTORE_BASE64` with the text from `keystore-base64.txt` (in your private signing-key package).
3. Add `ANDROID_KEYSTORE_PASSWORD` with the password from `keystore-password.txt`.
4. Go to **Actions → Build Android app → Run workflow**.

Without these secrets the workflow still builds a test-signed APK, but to install a newer version you'd have to uninstall the old one first, which deletes your progress. Keep a backup of the key: if you lose it, the same thing happens.
