// Copies the browser builds of Capacitor and its plugins into www/vendor,
// so the app works without a bundler.
const fs = require("fs");
const path = require("path");
const files = {
  "@capacitor/core/dist/capacitor.js": "capacitor.js",
  "@capacitor/local-notifications/dist/plugin.js": "local-notifications.js",
  "@capacitor/preferences/dist/plugin.js": "preferences.js",
  "@capacitor-community/text-to-speech/dist/plugin.js": "text-to-speech.js",
};
const out = path.join(__dirname, "..", "www", "vendor");
fs.mkdirSync(out, { recursive: true });
for (const [src, dest] of Object.entries(files)) {
  const code = fs.readFileSync(require.resolve(src), "utf8").replace(/\/\/# sourceMappingURL=.*$/m, "");
  fs.writeFileSync(path.join(out, dest), code);
  console.log("copied", src, "->", "www/vendor/" + dest);
}
